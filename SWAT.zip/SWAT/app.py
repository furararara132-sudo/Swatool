from flask import Flask, render_template, request, jsonify
import json
import os
import random
import requests
import socket
import dns.resolver
import phonenumbers
from phonenumbers import carrier, geocoder, timezone
import subprocess
import time
import hashlib
import re

app = Flask(__name__)

# =========================
# TOR PROXY
# =========================
TOR_PORT = 9050

def check_tor_running():
    """Проверяет, запущен ли Tor на порту 9050"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        result = s.connect_ex(('127.0.0.1', TOR_PORT))
        s.close()
        return result == 0
    except:
        return False

def start_tor():
    """Запускает Tor как субпроцесс"""
    if check_tor_running():
        return True
    
    try:
        # Проверяем, установлен ли Tor
        tor_paths = ['tor', '/usr/bin/tor', '/usr/local/bin/tor']
        tor_cmd = None
        for path in tor_paths:
            if os.path.exists(path) or subprocess.call(['which', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0:
                tor_cmd = path
                break
        
        if not tor_cmd:
            print("[!] Tor not found. Install it: sudo apt install tor")
            return False
        
        # Запускаем Tor
        subprocess.Popen([tor_cmd, '--SocksPort', str(TOR_PORT)], 
                        stdout=subprocess.DEVNULL, 
                        stderr=subprocess.DEVNULL)
        
        # Ждем запуска
        for _ in range(15):
            time.sleep(1)
            if check_tor_running():
                print("[+] Tor started successfully")
                return True
        return False
    except Exception as e:
        print(f"[!] Error starting Tor: {e}")
        return False

def get_tor_session():
    """Возвращает сессию с Tor прокси (socks5)"""
    if check_tor_running():
        proxies = {
            'http': f'socks5h://127.0.0.1:{TOR_PORT}',
            'https': f'socks5h://127.0.0.1:{TOR_PORT}'
        }
        session = requests.Session()
        session.proxies.update(proxies)
        # Таймауты, чтобы не зависало
        session.timeout = 15
        return session
    else:
        # Пытаемся запустить Tor
        if start_tor():
            return get_tor_session()
        else:
            # Fallback - без прокси
            print("[!] Tor not available, using direct connection")
            return requests.Session()

def get_my_ip(use_tor=True):
    """Получить свой IP через Tor или напрямую"""
    try:
        if use_tor:
            session = get_tor_session()
            print(f"[*] Getting IP via Tor...")
        else:
            session = requests.Session()
            print(f"[*] Getting IP directly...")
        
        # ip-api.com (быстрый и надежный)
        url = "http://ip-api.com/json/?fields=query"
        response = session.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            ip = data.get('query')
            if ip:
                print(f"[+] IP: {ip}")
                return ip
        
        # Резерв: api.ipify.org
        url = "https://api.ipify.org?format=json"
        response = session.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            ip = data.get('ip')
            if ip:
                print(f"[+] IP (backup): {ip}")
                return ip
        
        return None
    except Exception as e:
        print(f"[!] Error getting IP: {e}")
        return None

def get_tor_session():
    if check_tor_running():
        proxies = {
            'http': f'socks5h://127.0.0.1:{TOR_PORT}',
            'https': f'socks5h://127.0.0.1:{TOR_PORT}'
        }
        session = requests.Session()
        session.proxies.update(proxies)
        return session
    else:
        if start_tor():
            return get_tor_session()
        else:
            return requests.Session()

# =========================
# ГОРОДА ДЛЯ КАРТЫ
# =========================
cities = [
    {"name": "Лондон", "lat": 51.5074, "lon": -0.1278},
    {"name": "Париж", "lat": 48.8566, "lon": 2.3522},
    {"name": "Берлин", "lat": 52.5200, "lon": 13.4050},
    {"name": "Рим", "lat": 41.9028, "lon": 12.4964},
    {"name": "Мадрид", "lat": 40.4168, "lon": -3.7038},
    {"name": "Варшава", "lat": 52.2297, "lon": 21.0122},
    {"name": "Прага", "lat": 50.0755, "lon": 14.4378},
    {"name": "Вена", "lat": 48.2082, "lon": 16.3738},
    {"name": "Будапешт", "lat": 47.4979, "lon": 19.0402},
    {"name": "Стамбул", "lat": 41.0082, "lon": 28.9784},
    {"name": "Киев", "lat": 50.4501, "lon": 30.5234},
    {"name": "Минск", "lat": 53.9006, "lon": 27.5590},
    {"name": "Москва", "lat": 55.7558, "lon": 37.6173},
    {"name": "Санкт-Петербург", "lat": 59.9343, "lon": 30.3351},
    {"name": "Тбилиси", "lat": 41.7151, "lon": 44.8271},
    {"name": "Ереван", "lat": 40.1792, "lon": 44.4991},
    {"name": "Баку", "lat": 40.4093, "lon": 49.8671},
    {"name": "Астана", "lat": 51.1694, "lon": 71.4491},
    {"name": "Алматы", "lat": 43.2389, "lon": 76.8897},
    {"name": "Ташкент", "lat": 41.2995, "lon": 69.2401},
    {"name": "Токио", "lat": 35.6762, "lon": 139.6503},
    {"name": "Сеул", "lat": 37.5665, "lon": 126.9780},
    {"name": "Пекин", "lat": 39.9042, "lon": 116.4074},
    {"name": "Шанхай", "lat": 31.2304, "lon": 121.4737},
    {"name": "Гонконг", "lat": 22.3193, "lon": 114.1694},
    {"name": "Бангкок", "lat": 13.7563, "lon": 100.5018},
    {"name": "Сингапур", "lat": 1.3521, "lon": 103.8198},
    {"name": "Джакарта", "lat": -6.2088, "lon": 106.8456},
    {"name": "Дели", "lat": 28.6139, "lon": 77.2090},
    {"name": "Дубай", "lat": 25.2048, "lon": 55.2708},
    {"name": "Нью-Йорк", "lat": 40.7128, "lon": -74.0060},
    {"name": "Лос-Анджелес", "lat": 34.0522, "lon": -118.2437},
    {"name": "Чикаго", "lat": 41.8781, "lon": -87.6298},
    {"name": "Торонто", "lat": 43.6532, "lon": -79.3832},
    {"name": "Мехико", "lat": 19.4326, "lon": -99.1332},
    {"name": "Сан-Паулу", "lat": -23.5505, "lon": -46.6333},
    {"name": "Буэнос-Айрес", "lat": -34.6037, "lon": -58.3816},
    {"name": "Сидней", "lat": -33.8688, "lon": 151.2093},
    {"name": "Кейптаун", "lat": -33.9249, "lon": 18.4241},
    {"name": "Каир", "lat": 30.0444, "lon": 31.2357},
    {"name": "Найроби", "lat": -1.2921, "lon": 36.8219},
]

# =========================
# ФАЙЛ С МЕТКАМИ
# =========================
MARKERS_FILE = "markers.json"

if not os.path.exists(MARKERS_FILE):
    with open(MARKERS_FILE, "w", encoding="utf-8") as f:
        json.dump([], f)

def load_markers():
    with open(MARKERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_markers(markers):
    with open(MARKERS_FILE, "w", encoding="utf-8") as f:
        json.dump(markers, f, ensure_ascii=False, indent=4)

# =========================
# ОСНОВНЫЕ ФУНКЦИИ
# =========================

def obfuscate_text(text, intensity=1):
    if not text:
        return text
    
    REPLACE_MAP = {
        'а': 'a', 'А': 'A', 'в': 'B', 'В': 'B', 'е': 'e', 'Е': 'E',
        'к': 'k', 'К': 'K', 'м': 'M', 'М': 'M', 'н': 'H', 'Н': 'H',
        'о': 'o', 'О': '0', 'р': 'p', 'Р': 'P', 'с': 'c', 'С': 'C',
        'т': 't', 'Т': 'T', 'у': 'y', 'У': 'Y', 'х': 'x', 'Х': 'X',
        'и': 'u', 'п': 'n'
    }
    
    WORD_PATTERNS = {
        r'бомб[аы]': 'b0mba', r'тер[ао]кт': 'Terr0r', r'сваттинг': 'sw4tt1ng',
        r'полици[яи]': 'p0l1c3', r'спецслужб[аы]': 'sp3c5rv', r'убийств[оа]': 'k1ll1ng',
        r'взрыв': '3xpl0d3', r'оружи[ея]': 'w34p0n', r'наркотик[и]': 'n4rc0',
        r'хакер': 'h4x0r', r'взл[оа]м': 'h4ck', r'шпион': 'spy0n',
    }
    
    for pattern, replacement in WORD_PATTERNS.items():
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    
    new_text = []
    for char in text:
        if char in REPLACE_MAP:
            if intensity >= 2 and random.random() < 0.3:
                if char.lower() in 'аоеи':
                    new_text.append(random.choice(['0', 'o', 'O']))
                elif char.lower() in 'нмрт':
                    new_text.append(random.choice(['h', 'm', 'p', 't', 'r']))
                else:
                    new_text.append(REPLACE_MAP[char])
            else:
                new_text.append(REPLACE_MAP[char])
        else:
            if intensity >= 3 and random.random() < 0.15:
                if char.isalpha():
                    new_text.append(char.swapcase())
                else:
                    new_text.append(char)
            else:
                new_text.append(char)
    
    result = ''.join(new_text)
    
    if intensity >= 3:
        invisible_chars = ['\u200b', '\u200c', '\u200d']
        parts = list(result)
        for i in range(0, len(parts), random.randint(5, 15)):
            if i < len(parts):
                parts[i] = parts[i] + random.choice(invisible_chars)
        result = ''.join(parts)
    
    return result

def search_phone(phone_number):
    results = {
        'number': phone_number,
        'valid': False,
        'country': None,
        'carrier': None,
        'location': None,
        'timezone': None,
        'is_possible': False
    }
    try:
        parsed = phonenumbers.parse(phone_number, None)
        if phonenumbers.is_valid_number(parsed):
            results['valid'] = True
            results['country'] = phonenumbers.region_code_for_number(parsed)
            results['carrier'] = carrier.name_for_number(parsed, 'ru')
            results['location'] = geocoder.description_for_number(parsed, 'ru')
            results['timezone'] = timezone.time_zones_for_number(parsed)
            results['is_possible'] = phonenumbers.is_possible_number(parsed)
    except:
        pass
    return results

def search_email(email):
    import re as re_module
    results = {
        'email': email,
        'exposed': False,
        'breaches': [],
        'breach_count': 0,
        'mx_records': [],
        'smtp_verify': False,
        'domain': email.split('@')[-1] if '@' in email else None,
        'hash': hashlib.sha256(email.encode()).hexdigest()[:16]
    }
    
    session = get_tor_session()
    
    try:
        url = f"https://api.xposedornot.com/v1/breaches?email={email}"
        response = session.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('breaches'):
                results['exposed'] = True
                results['breaches'] = data['breaches'][:5]
                results['breach_count'] = len(data['breaches'])
    except:
        pass
    
    if not results['exposed']:
        try:
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
            response = session.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data:
                    results['exposed'] = True
                    results['breaches'] = [b.get('Name', 'Unknown') for b in data[:5]]
                    results['breach_count'] = len(data)
        except:
            pass
    
    if results['domain']:
        try:
            mx_records = dns.resolver.resolve(results['domain'], 'MX')
            results['mx_records'] = [str(r.exchange) for r in mx_records][:3]
        except:
            pass
    
    try:
        if results['mx_records']:
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            test_socket.settimeout(3)
            result = test_socket.connect_ex((results['mx_records'][0], 25))
            test_socket.close()
            results['smtp_verify'] = (result == 0)
    except:
        pass
    
    return results

def search_ip(ip_address):
    results = {
        'ip': ip_address,
        'country': None,
        'city': None,
        'region': None,
        'latitude': None,
        'longitude': None,
        'isp': None,
        'org': None,
        'timezone': None,
        'asn': None,
        'hostname': None,
        'coordinates_url': None
    }
    
    session = get_tor_session()
    
    try:
        url = f"http://ip-api.com/json/{ip_address}?fields=status,message,country,city,regionName,lat,lon,isp,org,timezone,as,hosting,query"
        response = session.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                results['country'] = data.get('country')
                results['city'] = data.get('city')
                results['region'] = data.get('regionName')
                results['latitude'] = data.get('lat')
                results['longitude'] = data.get('lon')
                results['isp'] = data.get('isp')
                results['org'] = data.get('org')
                results['timezone'] = data.get('timezone')
                results['asn'] = data.get('as')
                results['hostname'] = data.get('hosting')
                if results['latitude'] and results['longitude']:
                    results['coordinates_url'] = f"http://127.0.0.1:5000/map?lat={results['latitude']}&lon={results['longitude']}&radius=50"
    except:
        pass
    
    if not results['country']:
        try:
            url = f"https://ipinfo.io/{ip_address}/json"
            response = session.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if 'loc' in data:
                    loc = data['loc'].split(',')
                    results['latitude'] = float(loc[0])
                    results['longitude'] = float(loc[1])
                    results['coordinates_url'] = f"http://127.0.0.1:5000/map?lat={results['latitude']}&lon={results['longitude']}&radius=50"
                results['country'] = data.get('country')
                results['city'] = data.get('city')
                results['region'] = data.get('region')
                results['isp'] = data.get('org')
                results['hostname'] = data.get('hostname')
        except:
            pass
    
    return results

def generate_swat_identity(gender, city, phone=None, email=None, ip=None, incident=None):
    first_names_male = ['Александр', 'Дмитрий', 'Максим', 'Сергей', 'Андрей', 'Алексей', 'Иван', 'Евгений', 'Николай', 'Владимир',
                        'Марк', 'Артем', 'Михаил', 'Даниил', 'Егор', 'Никита', 'Илья', 'Кирилл', 'Глеб', 'Тимофей']
    first_names_female = ['Анна', 'Екатерина', 'Ольга', 'Татьяна', 'Мария', 'Светлана', 'Наталья', 'Елена', 'Ирина', 'Юлия',
                          'Алиса', 'Виктория', 'Анастасия', 'Дарья', 'Полина', 'Ксения', 'Валерия', 'Елизавета']
    last_names = ['Смирнов', 'Иванов', 'Кузнецов', 'Попов', 'Соколов', 'Лебедев', 'Козлов', 'Новиков', 'Морозов', 'Петров',
                  'Волков', 'Зайцев', 'Соловьев', 'Васильев', 'Михайлов', 'Федоров', 'Андреев', 'Алексеев']
    middle_names_male = ['Александрович', 'Дмитриевич', 'Максимович', 'Сергеевич', 'Андреевич', 'Алексеевич', 'Иванович']
    middle_names_female = ['Александровна', 'Дмитриевна', 'Максимовна', 'Сергеевна', 'Андреевна', 'Алексеевна', 'Ивановна']
    streets = ['Ленина', 'Пушкина', 'Советская', 'Мира', 'Гагарина', 'Кирова', 'Комсомольская', 'Октябрьская', 'Первомайская', 
               'Дзержинского', 'Центральная', 'Молодежная', 'Строителей', 'Школьная', 'Садовая', 'Набережная', 'Лесная', 'Полевая']
    jobs = ['Инженер', 'Программист', 'Менеджер', 'Врач', 'Юрист', 'Аналитик', 'Консультант', 'Директор', 'Архитектор', 
            'Фармацевт', 'Бухгалтер', 'Преподаватель', 'Пилот', 'Журналист', 'Дизайнер', 'Фотограф']
    companies = ['ООО "ТехноСервис"', 'ЗАО "СтройИнвест"', 'ООО "Альфа-Групп"', 'ООО "Интеллект"', 'ЗАО "Прогресс"', 'ООО "Лидер"',
                 'ООО "Глобал"', 'ЗАО "Энергия"', 'ООО "Технопарк"', 'АО "Развитие"']
    
    incidents = {
        'armed_person': 'Вооруженный человек в здании',
        'hostage': 'Захват заложников',
        'bomb': 'Угроза взрыва',
        'shooting': 'Стрельба в общественном месте',
        'gas_leak': 'Утечка газа',
        'fire': 'Пожар в здании'
    }
    
    incident_descriptions = {
        'armed_person': 'В здании находится вооруженный человек с автоматом. Слышны выстрелы.',
        'hostage': 'Неизвестный удерживает заложников в помещении. Требует переговоров.',
        'bomb': 'Обнаружено взрывное устройство. Возможна детонация.',
        'shooting': 'Стрельба в общественном месте. Есть раненые.',
        'gas_leak': 'Сильная утечка газа в здании. Запах газа на всех этажах.',
        'fire': 'Возгорание на верхних этажах. Есть угроза обрушения.'
    }
    
    is_male = gender == 'male'
    first_name = random.choice(first_names_male if is_male else first_names_female)
    last_name = random.choice(last_names)
    middle_name = random.choice(middle_names_male if is_male else middle_names_female)
    
    age = random.randint(20, 55)
    birth_date = time.strftime('%d.%m.%Y', time.localtime(time.time() - age*365*24*3600 - random.randint(0, 365)*24*3600))
    birth_year = int(birth_date.split('.')[-1])
    
    if not city:
        city_list = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань', 'Нижний Новгород', 'Челябинск', 'Омск', 'Ростов-на-Дону', 'Уфа']
        city = random.choice(city_list)
    
    street = random.choice(streets)
    house = random.randint(1, 150)
    apartment = random.randint(1, 200) if random.random() > 0.3 else None
    address = f"{city}, ул. {street}, д. {house}" + (f", кв. {apartment}" if apartment else "")
    
    if not phone:
        phone = f"+7{random.randint(900, 999)}{''.join([str(random.randint(0,9)) for _ in range(7)])}"
    
    passport_series = f"{random.randint(10, 99)}{random.randint(10, 99)}"
    passport_number = f"{random.randint(100000, 999999)}"
    passport_issued = f"ОВД {city} района" if random.random() > 0.3 else f"УФМС по {city}"
    passport_code = f"{random.randint(100, 999)}-{random.randint(100, 999)}"
    
    full_name = f"{last_name} {first_name} {middle_name}"
    
    incident_key = incident if incident in incidents else 'armed_person'
    incident_name = incidents.get(incident_key, incidents['armed_person'])
    incident_desc = incident_descriptions.get(incident_key, incident_descriptions['armed_person'])
    
    height = random.randint(165, 195) if is_male else random.randint(155, 180)
    weight = random.randint(65, 110) if is_male else random.randint(50, 85)
    hair = random.choice(['блондин', 'брюнет', 'шатен', 'рыжий', 'седой'])
    eyes = random.choice(['голубые', 'карие', 'зеленые', 'серые', 'темные'])
    
    result = {
        'identity': {
            'full_name': full_name,
            'first_name': first_name,
            'last_name': last_name,
            'middle_name': middle_name,
            'gender': 'male' if is_male else 'female',
            'gender_label': 'Мужской' if is_male else 'Женский',
            'birth_date': birth_date,
            'age': age,
            'birth_year': birth_year,
            'phone': phone,
            'email': email,
            'address': address,
            'city': city,
            'street': street,
            'house': house,
            'apartment': apartment,
            'passport_series': passport_series,
            'passport_number': passport_number,
            'passport_issued': passport_issued,
            'passport_code': passport_code,
            'passport_full': f"{passport_series} {passport_number}",
            'job': random.choice(jobs),
            'company': random.choice(companies),
            'height': height,
            'weight': weight,
            'hair': hair,
            'eyes': eyes,
        },
        'incident': {
            'type': incident_key,
            'name': incident_name,
            'description': incident_desc,
            'location': address,
            'city': city
        }
    }
    
    if email:
        try:
            result['victim_email_data'] = search_email(email)
        except:
            result['victim_email_data'] = None
    
    if ip:
        try:
            ip_data = search_ip(ip)
            result['victim_ip_data'] = ip_data
            if not city and ip_data.get('city'):
                result['identity']['city'] = ip_data.get('city')
                result['identity']['address'] = f"{ip_data.get('city')}, ул. {street}, д. {house}" + (f", кв. {apartment}" if apartment else "")
                result['incident']['city'] = ip_data.get('city')
                result['incident']['location'] = result['identity']['address']
        except:
            result['victim_ip_data'] = None
    
    if phone:
        try:
            result['victim_phone_data'] = search_phone(phone)
        except:
            result['victim_phone_data'] = None
    
    return result

def generate_call_script(incident_type, location, name, tone='panicky'):
    """Генерация скрипта для звонка"""
    
    scripts = {
        'armed_person': {
            'panicky': [
                f"Алло! Это полиция?! У нас тут... у нас тут человек с оружием! Пожалуйста, быстрее! Он в {location}!",
                f"Он кричит что-то, я слышал выстрелы! Я в соседней квартире, боюсь выходить! Пожалуйста, приезжайте! Срочно!",
                f"Диспетчер, это не шутка! Я видел его! У него автомат! Пожалуйста, скорее!"
            ],
            'cold': [
                f"Здравствуйте. Сообщаю о вооруженном человеке по адресу {location}.",
                f"Мужчина с автоматом. Слышны выстрелы. Требуется немедленное вмешательство.",
                f"Я не шучу. Это реальная угроза. Приезжайте с оружием."
            ],
            'excited': [
                f"СЛУШАЙТЕ! Там человек с ОРУЖИЕМ! Адрес {location}! Я ВИДЕЛ ЕГО!",
                f"Он стреляет! Вы слышите?! Это реально! ПРИЕЗЖАЙТЕ СЕЙЧАС ЖЕ!",
                f"Я не могу говорить, он идет сюда! БЫСТРЕЕ!"
            ]
        },
        'hostage': {
            'panicky': [
                f"Алло! У нас тут захват заложников! Адрес {location}!",
                f"Человек ворвался, у него оружие, он держит людей! Пожалуйста, приезжайте!",
                f"Я слышу крики! Он что-то требует! Я боюсь за них! СРОЧНО!"
            ],
            'cold': [
                f"Сообщаю о захвате заложников по адресу {location}.",
                f"Вооруженный мужчина удерживает людей. Требует переговоров.",
                f"Информация достоверная. Необходимо вмешательство спецслужб."
            ],
            'excited': [
                f"ЗАХВАТ ЗАЛОЖНИКОВ! Адрес {location}! ОН ВОРВАЛСЯ С ОРУЖИЕМ!",
                f"ЛЮДИ В ОПАСНОСТИ! БЫСТРЕЕ! ОН МОЖЕТ ИХ УБИТЬ!",
                f"Я СЛЫШУ КРИКИ! ПРИЕЗЖАЙТЕ НЕМЕДЛЕННО!"
            ]
        },
        'bomb': {
            'panicky': [
                f"Алло! Бомба! Я нашел взрывное устройство по адресу {location}!",
                f"Там какая-то штука с проводами! Я боюсь трогать! Высылайте саперов!",
                f"Пожалуйста, быстрее! Я не знаю, когда это взорвется!"
            ],
            'cold': [
                f"Сообщаю о взрывном устройстве по адресу {location}.",
                f"Обнаружена подозрительная конструкция с проводами. Возможно, бомба.",
                f"Требуется срочное прибытие саперов и оцепление территории."
            ],
            'excited': [
                f"БОМБА! ТАМ БОМБА! Адрес {location}! ОНА МОЖЕТ ВЗОРВАТЬСЯ!",
                f"Я ВИДЕЛ ПРОВОДА И КАКОЙ-ТО ПРИБОР! БЫСТРО ПРИЕЗЖАЙТЕ!",
                f"ЭТО НЕ ШУТКА! ВЫСЫЛАЙТЕ ВСЕХ!"
            ]
        },
        'shooting': {
            'panicky': [
                f"Алло! Стрельба! В {location} стреляют!",
                f"Я слышал выстрелы, потом крики! Несколько человек упали!",
                f"Пожалуйста, приезжайте! Я боюсь выходить из укрытия!"
            ],
            'cold': [
                f"Сообщаю о стрельбе по адресу {location}.",
                f"Несколько выстрелов, есть пострадавшие. Требуется срочное вмешательство.",
                f"Стрельба продолжается. Приезжайте с оружием."
            ],
            'excited': [
                f"СТРЕЛЬБА! В {location} СТРЕЛЬБА! ЛЮДИ УМИРАЮТ!",
                f"Я СЛЫШУ ВЫСТРЕЛЫ! КТО-ТО КРИЧИТ! БЫСТРО ПРИЕЗЖАЙТЕ!",
                f"ЭТО РЕАЛЬНО, Я НЕ ШУЧУ! СРОЧНО!"
            ]
        },
        'gas_leak': {
            'panicky': [
                f"Алло! Утечка газа! В {location} сильный запах газа!",
                f"Я чувствую газ на всех этажах! Может взорваться!",
                f"Пожалуйста, высылайте МЧС и газовую службу!"
            ],
            'cold': [
                f"Сообщаю об утечке газа по адресу {location}.",
                f"Сильный запах газа в подъезде. Требуется эвакуация.",
                f"Возможен взрыв. Принимайте меры."
            ],
            'excited': [
                f"ГАЗ! УТЕЧКА ГАЗА! Адрес {location}! МОЖЕТ ВЗОРВАТЬСЯ!",
                f"ЗАПАХ НА ВСЕХ ЭТАЖАХ! ВЫВОДИТЕ ЛЮДЕЙ! БЫСТРО!"
            ]
        },
        'fire': {
            'panicky': [
                f"Пожар! В {location} пожар! Горит верхний этаж!",
                f"Огонь распространяется, люди в здании! Высылайте пожарных!",
                f"Я вижу дым и пламя! СРОЧНО!"
            ],
            'cold': [
                f"Сообщаю о пожаре по адресу {location}.",
                f"Горит верхний этаж. Есть угроза обрушения.",
                f"Необходима эвакуация и помощь пожарных."
            ],
            'excited': [
                f"ПОЖАР! ЗДАНИЕ ГОРИТ! Адрес {location}! ЛЮДИ ВНУТРИ!",
                f"ОГОНЬ РАСПРОСТРАНЯЕТСЯ! ПРИЕЗЖАЙТЕ СРОЧНО!"
            ]
        }
    }
    
    tone_map = {
        'panicky': 'панический',
        'cold': 'холодный',
        'excited': 'взволнованный'
    }
    
    incident_script = scripts.get(incident_type, scripts['armed_person'])
    lines = incident_script.get(tone, incident_script['panicky'])
    
    # Подстановка имени и локации
    lines = [line.replace('{location}', location).replace('{name}', name) for line in lines]
    
    # Фразы диспетчера
    dispatcher_responses = [
        '[Диспетчер: Назовите точный адрес]',
        '[Диспетчер: Уточните, что происходит]',
        '[Диспетчер: Есть ли пострадавшие?]',
        '[Диспетчер: Вы в безопасности?]',
        '[Диспетчер: Ждите, полиция уже выехала]'
    ]
    
    # Сборка скрипта
    script = []
    script.append(f"=== СКРИПТ ЗВОНКА ===\n")
    script.append(f"Тон: {tone_map.get(tone, 'панический')}")
    script.append(f"Инцидент: {incident_type.replace('_', ' ').upper()}")
    script.append(f"Адрес: {location}\n")
    
    for i, line in enumerate(lines):
        script.append(f"[Вы] {line}")
        if i < len(lines) - 1:
            script.append(random.choice(dispatcher_responses))
    
    script.append("\n[Диспетчер: Полиция выехала. Оставайтесь на линии]")
    script.append("[Вы] Спасибо, я жду. Только быстрее, пожалуйста.")
    
    return '\n'.join(script)

# =========================
# ROUTES
# =========================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/map')
def map_page():
    return render_template('map.html', 
                          cities=json.dumps(cities, ensure_ascii=False),
                          custom_markers=json.dumps(load_markers(), ensure_ascii=False))

@app.route('/add_marker', methods=['POST'])
def add_marker():
    data = request.json
    markers = load_markers()
    markers.append({
        "name": data["name"],
        "lat": data["lat"],
        "lon": data["lon"]
    })
    save_markers(markers)
    return jsonify({"success": True})

@app.route('/clear_markers', methods=['POST'])
def clear_markers():
    save_markers([])
    return jsonify({"success": True})

@app.route('/obfuscate', methods=['POST'])
def obfuscate():
    data = request.get_json()
    text = data.get('text', '')
    intensity = int(data.get('intensity', 1))
    if not text:
        return jsonify({'error': 'No text provided'}), 400
    return jsonify({'obfuscated': obfuscate_text(text, intensity)})

@app.route('/search/phone', methods=['POST'])
def search_phone_route():
    data = request.get_json()
    phone = data.get('phone', '')
    if not phone:
        return jsonify({'error': 'Phone number required'}), 400
    return jsonify(search_phone(phone))

@app.route('/search/email', methods=['POST'])
def search_email_route():
    data = request.get_json()
    email = data.get('email', '')
    if not email:
        return jsonify({'error': 'Email required'}), 400
    return jsonify(search_email(email))

@app.route('/search/ip', methods=['POST'])
def search_ip_route():
    data = request.get_json()
    ip = data.get('ip', '')
    if not ip:
        return jsonify({'error': 'IP address required'}), 400
    return jsonify(search_ip(ip))

@app.route('/tor/status', methods=['GET'])
def tor_status():
    tor_running = check_tor_running()
    
    # Получаем IP без Tor
    normal_ip = get_my_ip(use_tor=False)
    
    # Получаем IP через Tor (только если Tor запущен)
    tor_ip = None
    tor_working = False
    if tor_running:
        tor_ip = get_my_ip(use_tor=True)
        # Если IP разные — Tor работает
        if tor_ip and normal_ip and tor_ip != normal_ip:
            tor_working = True
        # Если Tor запущен но IP одинаковый — проблема с прокси
        elif tor_ip and normal_ip and tor_ip == normal_ip:
            tor_working = False
            print("[!] Tor running but IP not changed — proxy issue")
    
    return jsonify({
        'running': tor_running,
        'port': TOR_PORT,
        'my_ip_normal': normal_ip,
        'my_ip_tor': tor_ip,
        'tor_working': tor_working
    })

@app.route('/swat/prep', methods=['POST'])
def swat_prep():
    data = request.get_json()
    result = generate_swat_identity(
        data.get('gender', 'male'),
        data.get('city', ''),
        data.get('phone', ''),
        data.get('email', ''),
        data.get('ip', ''),
        data.get('incident', 'armed_person')
    )
    return jsonify(result)

@app.route('/call/script', methods=['POST'])
def call_script():
    data = request.get_json()
    incident = data.get('incident', 'armed_person')
    location = data.get('location', 'неизвестный адрес')
    name = data.get('name', 'человек')
    tone = data.get('tone', 'panicky')
    script = generate_call_script(incident, location, name, tone)
    return jsonify({'script': script})

if __name__ == '__main__':
    if not check_tor_running():
        print("[*] Tor not running. Attempting to start...")
        if start_tor():
            print("[+] Tor started successfully on port 9050")
        else:
            print("[!] Tor could not be started. Using direct connection.")
    app.run(debug=True, host='0.0.0.0', port=5000)